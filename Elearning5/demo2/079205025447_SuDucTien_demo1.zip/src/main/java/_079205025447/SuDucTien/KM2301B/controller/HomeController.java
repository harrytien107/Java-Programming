package _079205025447.SuDucTien.KM2301B.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.Model;

import _079205025447.SuDucTien.KM2301B.service.IStudentService;
import _079205025447.SuDucTien.KM2301B.service.StudentService;
import _079205025447.SuDucTien.KM2301B.pojo.Student;

import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

@Controller
public class HomeController {
    private IStudentService iStudentService;

    public HomeController() {
        iStudentService = new StudentService("JPAs");
    }

    @RequestMapping(value = "/")
    public ModelAndView showStudent(HttpServletRequest request) throws IOException {
        ModelAndView modelAndView = new ModelAndView("home");
        List<Student> students = iStudentService.findAll();
        modelAndView.addObject("studentList", students);
        return modelAndView;
    }

    @PostMapping(value = "/manageStudent")
    public String manageStudent(HttpServletRequest request) throws IOException {
        String type = request.getParameter("btnManageStudent");
        
        if (type != null) {
            switch (type) {
                case "Add":
                    String idParam = request.getParameter("txtID");
                    if (idParam == null || idParam.trim().isEmpty()) {
                        // Handle empty ID error
                        return "redirect:/?error=ID cannot be empty";
                    }
                    int addId = Integer.parseInt(idParam);
                    String firstName = request.getParameter("txtFirstName");
                    String lastName = request.getParameter("txtLastName");
                    int marks = Integer.parseInt(request.getParameter("txtMarks"));
                    Student student = new Student(firstName, lastName, marks);
                    student.setId(addId);
                    iStudentService.save(student);
                    break;
                case "Update":
                    String originalIdParam = request.getParameter("originalID");
                    String newIdParam = request.getParameter("txtID");
                    
                    if (originalIdParam == null || originalIdParam.trim().isEmpty()) {
                        return "redirect:/?error=Please select a student to update";
                    }
                    
                    int originalId = Integer.parseInt(originalIdParam);
                    int newId = Integer.parseInt(newIdParam);
                    
                    String updateFirstName = request.getParameter("txtFirstName");
                    String updateLastName = request.getParameter("txtLastName");
                    int updateMarks = Integer.parseInt(request.getParameter("txtMarks"));
                    
                    // If ID is changing, we need to handle it specially
                    if (originalId != newId) {
                        // Check if new ID already exists
                        Student existingStudent = iStudentService.findById(newId);
                        if (existingStudent != null) {
                            return "redirect:/?error=Student with ID " + newId + " already exists";
                        }
                        
                        // Delete old record and create new one with new ID
                        iStudentService.delete(originalId);
                        Student newStudent = new Student(updateFirstName, updateLastName, updateMarks);
                        newStudent.setId(newId);
                        iStudentService.save(newStudent);
                    } else {
                        // Same ID, just update fields
                        Student updateStudent = new Student(updateFirstName, updateLastName, updateMarks);
                        updateStudent.setId(newId);
                        iStudentService.update(updateStudent);
                    }
                    break;
                case "Delete":
                    int studentID = Integer.parseInt(request.getParameter("txtID"));
                    iStudentService.delete(studentID);
                    break;
            }
        }
        return "redirect:/";
    }

    @GetMapping(value = "/admin")
    public ModelAndView showAdmin() {
        ModelAndView modelAndView = new ModelAndView("admin");
        List<Student> students = iStudentService.findAll();
        modelAndView.addObject("studentList", students);
        
        // Add statistics
        modelAndView.addObject("totalStudents", students.size());
        if (!students.isEmpty()) {
            double avgMarks = students.stream().mapToInt(Student::getMarks).average().orElse(0.0);
            modelAndView.addObject("averageMarks", String.format("%.2f", avgMarks));
            
            int maxMarks = students.stream().mapToInt(Student::getMarks).max().orElse(0);
            int minMarks = students.stream().mapToInt(Student::getMarks).min().orElse(0);
            modelAndView.addObject("maxMarks", maxMarks);
            modelAndView.addObject("minMarks", minMarks);
        } else {
            modelAndView.addObject("averageMarks", "0.00");
            modelAndView.addObject("maxMarks", 0);
            modelAndView.addObject("minMarks", 0);
        }
        
        return modelAndView;
    }
}
