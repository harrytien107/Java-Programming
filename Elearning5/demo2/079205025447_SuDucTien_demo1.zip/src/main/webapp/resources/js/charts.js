/**
 * Charts and Data Visualization for Student Management System
 */

const ChartManager = {
    // Chart instances storage
    charts: {},

    // Chart configurations
    config: {
        defaultColors: [
            '#667eea',
            '#764ba2', 
            '#28a745',
            '#ffc107',
            '#dc3545',
            '#17a2b8',
            '#6f42c1',
            '#fd7e14'
        ],
        animation: {
            duration: 1500,
            easing: 'easeInOutQuart'
        }
    },

    // Initialize all charts
    init() {
        this.initializeGradeChart();
        this.initializePerformanceChart();
        this.initializeTrendChart();
        this.initializeStatistics();
    },

    // Initialize grade distribution chart (Doughnut)
    initializeGradeChart() {
        const ctx = document.getElementById('gradeChart');
        if (!ctx) return;

        // Get student data from the page
        const studentData = this.getStudentData();
        const gradeDistribution = this.calculateGradeDistribution(studentData);

        this.charts.gradeChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Excellent (90-100)', 'Good (75-89)', 'Average (60-74)', 'Poor (0-59)'],
                datasets: [{
                    data: gradeDistribution,
                    backgroundColor: [
                        '#28a745',
                        '#17a2b8', 
                        '#ffc107',
                        '#dc3545'
                    ],
                    borderWidth: 3,
                    borderColor: '#fff',
                    hoverBorderWidth: 5,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            font: {
                                size: 12,
                                weight: '500'
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((context.parsed / total) * 100).toFixed(1);
                                return `${context.label}: ${context.parsed} students (${percentage}%)`;
                            }
                        },
                        backgroundColor: 'rgba(0,0,0,0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: '#667eea',
                        borderWidth: 1
                    }
                },
                animation: this.config.animation,
                cutout: '60%',
                elements: {
                    arc: {
                        borderJoinStyle: 'round'
                    }
                }
            }
        });

        // Add center text
        this.addCenterText(ctx, studentData.length, 'Total Students');
    },

    // Initialize performance chart (Bar)
    initializePerformanceChart() {
        const ctx = document.getElementById('performanceChart');
        if (!ctx) return;

        const studentData = this.getStudentData();
        const labels = studentData.map(s => s.firstName);
        const scores = studentData.map(s => s.marks);

        this.charts.performanceChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Student Scores',
                    data: scores,
                    backgroundColor: scores.map(score => this.getScoreColor(score)),
                    borderColor: '#667eea',
                    borderWidth: 2,
                    borderRadius: 8,
                    borderSkipped: false,
                    hoverBackgroundColor: '#764ba2',
                    hoverBorderColor: '#fff',
                    hoverBorderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        grid: {
                            color: 'rgba(0,0,0,0.1)',
                            lineWidth: 1
                        },
                        ticks: {
                            stepSize: 20,
                            callback: (value) => value + '%',
                            font: {
                                size: 11
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            maxRotation: 45,
                            font: {
                                size: 11
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                const score = context.parsed.y;
                                const grade = this.getGradeFromScore(score);
                                return `Score: ${score}% (${grade})`;
                            }
                        },
                        backgroundColor: 'rgba(0,0,0,0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff'
                    }
                },
                animation: {
                    ...this.config.animation,
                    delay: (context) => context.dataIndex * 100
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    },

    // Initialize trend chart (Line) - for admin dashboard
    initializeTrendChart() {
        const ctx = document.getElementById('trendChart');
        if (!ctx) return;

        // Sample trend data (in real app, this would come from backend)
        const trendData = this.generateTrendData();

        this.charts.trendChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: trendData.labels,
                datasets: [{
                    label: 'Average Score',
                    data: trendData.averageScores,
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#667eea',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6,
                    pointHoverRadius: 8
                }, {
                    label: 'Student Count',
                    data: trendData.studentCounts,
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#28a745',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6,
                    pointHoverRadius: 8,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        beginAtZero: true,
                        max: 100,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        },
                        ticks: {
                            callback: (value) => value + '%'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        beginAtZero: true,
                        grid: {
                            drawOnChartArea: false
                        },
                        ticks: {
                            callback: (value) => value + ' students'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            padding: 20
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'rgba(0,0,0,0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff'
                    }
                },
                animation: this.config.animation,
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });
    },

    // Initialize statistics animations
    initializeStatistics() {
        const statsElements = document.querySelectorAll('.stats-number, .stats-card h3');
        
        statsElements.forEach((element, index) => {
            this.animateStatistic(element, index * 200);
        });
    },

    // Animate statistics counter
    animateStatistic(element, delay = 0) {
        const finalValue = parseFloat(element.textContent) || 0;
        const isDecimal = element.textContent.includes('.');
        const duration = 2000;
        const frameRate = 60;
        const totalFrames = duration / (1000 / frameRate);
        const increment = finalValue / totalFrames;
        
        let currentValue = 0;
        let frame = 0;

        setTimeout(() => {
            const animation = () => {
                frame++;
                currentValue += increment;
                
                if (frame >= totalFrames) {
                    currentValue = finalValue;
                }
                
                if (isDecimal) {
                    element.textContent = currentValue.toFixed(2);
                } else {
                    element.textContent = Math.floor(currentValue);
                }
                
                if (frame < totalFrames) {
                    requestAnimationFrame(animation);
                }
            };
            animation();
        }, delay);
    },

    // Get student data from DOM
    getStudentData() {
        const studentData = [];
        const rows = document.querySelectorAll('table tbody tr');
        
        rows.forEach(row => {
            const cells = row.cells;
            if (cells.length >= 4) {
                const id = cells[1]?.textContent?.trim();
                const firstName = cells[2]?.textContent?.trim();
                const lastName = cells[3]?.textContent?.trim();
                const marksText = cells[4]?.textContent?.trim();
                const marks = parseInt(marksText) || 0;
                
                if (id && firstName && lastName) {
                    studentData.push({
                        id: id,
                        firstName: firstName,
                        lastName: lastName,
                        marks: marks
                    });
                }
            }
        });
        
        return studentData;
    },

    // Calculate grade distribution
    calculateGradeDistribution(studentData) {
        const distribution = [0, 0, 0, 0]; // Excellent, Good, Average, Poor
        
        studentData.forEach(student => {
            const marks = student.marks;
            if (marks >= 90) distribution[0]++;
            else if (marks >= 75) distribution[1]++;
            else if (marks >= 60) distribution[2]++;
            else distribution[3]++;
        });
        
        return distribution;
    },

    // Get color based on score
    getScoreColor(score) {
        if (score >= 90) return '#28a745'; // Green
        if (score >= 75) return '#17a2b8'; // Blue
        if (score >= 60) return '#ffc107'; // Yellow
        return '#dc3545'; // Red
    },

    // Get grade from score
    getGradeFromScore(score) {
        if (score >= 90) return 'Excellent';
        if (score >= 75) return 'Good';
        if (score >= 60) return 'Average';
        return 'Poor';
    },

    // Generate sample trend data
    generateTrendData() {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
        const averageScores = [75, 78, 82, 79, 85, 88];
        const studentCounts = [25, 28, 32, 30, 35, 38];
        
        return {
            labels: months,
            averageScores: averageScores,
            studentCounts: studentCounts
        };
    },

    // Add center text to doughnut chart
    addCenterText(ctx, value, label) {
        const chart = Chart.getChart(ctx);
        if (!chart) return;

        Chart.register({
            id: 'centerText',
            beforeDraw: function(chart) {
                if (chart.config.type !== 'doughnut') return;

                const { width, height, ctx } = chart;
                ctx.restore();

                const fontSize = (height / 114).toFixed(2);
                ctx.font = `bold ${fontSize}em Inter, sans-serif`;
                ctx.textBaseline = 'middle';
                ctx.fillStyle = '#2c3e50';

                const text = value.toString();
                const textX = Math.round((width - ctx.measureText(text).width) / 2);
                const textY = height / 2 - 10;

                ctx.fillText(text, textX, textY);

                // Add label
                ctx.font = `${fontSize * 0.6}em Inter, sans-serif`;
                ctx.fillStyle = '#6c757d';
                const labelX = Math.round((width - ctx.measureText(label).width) / 2);
                const labelY = height / 2 + 15;
                ctx.fillText(label, labelX, labelY);

                ctx.save();
            }
        });
    },

    // Update charts with new data
    updateCharts(newData) {
        if (this.charts.gradeChart && newData.students) {
            const distribution = this.calculateGradeDistribution(newData.students);
            this.charts.gradeChart.data.datasets[0].data = distribution;
            this.charts.gradeChart.update('active');
        }

        if (this.charts.performanceChart && newData.students) {
            const labels = newData.students.map(s => s.firstName);
            const scores = newData.students.map(s => s.marks);
            
            this.charts.performanceChart.data.labels = labels;
            this.charts.performanceChart.data.datasets[0].data = scores;
            this.charts.performanceChart.data.datasets[0].backgroundColor = scores.map(score => this.getScoreColor(score));
            this.charts.performanceChart.update('active');
        }
    },

    // Destroy all charts
    destroy() {
        Object.values(this.charts).forEach(chart => {
            if (chart) {
                chart.destroy();
            }
        });
        this.charts = {};
    },

    // Resize charts
    resize() {
        Object.values(this.charts).forEach(chart => {
            if (chart) {
                chart.resize();
            }
        });
    },

    // Export chart as image
    exportChart(chartName, filename = 'chart.png') {
        const chart = this.charts[chartName];
        if (!chart) return;

        const link = document.createElement('a');
        link.download = filename;
        link.href = chart.toBase64Image();
        link.click();
    },

    // Print chart
    printChart(chartName) {
        const chart = this.charts[chartName];
        if (!chart) return;

        const imageUrl = chart.toBase64Image();
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
                <head><title>Chart</title></head>
                <body style="margin:0;padding:20px;">
                    <img src="${imageUrl}" style="max-width:100%;height:auto;">
                </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    }
};

// Initialize charts when DOM is ready and Chart.js is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Check if Chart.js is loaded
    if (typeof Chart !== 'undefined') {
        ChartManager.init();
    } else {
        // Wait for Chart.js to load
        window.addEventListener('load', () => {
            if (typeof Chart !== 'undefined') {
                ChartManager.init();
            }
        });
    }
});

// Handle window resize
window.addEventListener('resize', () => {
    ChartManager.resize();
});

// Export for global access
window.ChartManager = ChartManager; 